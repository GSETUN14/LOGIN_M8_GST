package com.example.applogingst;

import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends AppCompatActivity {

    // Definir las vistas
    private EditText editTextUser, editTextPass;
    private Button loginButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inicializar vistas
        editTextUser = findViewById(R.id.editTextText);
        editTextPass = findViewById(R.id.editTextTextPassword);
        loginButton = findViewById(R.id.button);

        // Configurar el botón para realizar la validación de usuario y contraseña
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = editTextUser.getText().toString();
                String password = editTextPass.getText().toString();
                if (!username.isEmpty() && !password.isEmpty()) {
                    // Llamar a la función de validación
                    validateUser(username, password);
                } else {
                    Toast.makeText(MainActivity.this, "Por favor ingrese usuario y contraseña", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void validateUser(String username, String password) {
        // URL del servidor PHP para validar usuario
        String urlString = "http://10.0.2.2/applogingst/validacuenta.php"; // Cambiar si usas un servidor diferente

        // El hilo principal no debe bloquearse en operaciones de red, por lo que usamos StrictMode
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        try {
            // Establecer la conexión HTTP
            URL url = new URL(urlString);
            HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.setRequestMethod("POST");
            urlConnection.setDoOutput(true);

            // Crear el cuerpo de la solicitud POST con los parámetros correctos
            String postData = "user=" + username + "&pass=" + password;

            // Escribir los datos de la solicitud
            OutputStream outputStream = urlConnection.getOutputStream();
            outputStream.write(postData.getBytes());
            outputStream.flush();
            outputStream.close();

            // Leer la respuesta del servidor
            BufferedReader in = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
            String responseLine;
            StringBuilder response = new StringBuilder();
            while ((responseLine = in.readLine()) != null) {
                response.append(responseLine);
            }
            in.close();

            // Verificar la respuesta del servidor
            if (response.toString().contains("success")) {
                runOnUiThread(() -> {
                    Toast.makeText(MainActivity.this, "Login exitoso", Toast.LENGTH_SHORT).show();
                    // Redirigir a la nueva actividad
                    Intent intent = new Intent(MainActivity.this, UserListActivity.class);
                    startActivity(intent);
                });
            } else {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "Usuario o contraseña incorrectos", Toast.LENGTH_SHORT).show());
            }

        } catch (IOException e) {
            runOnUiThread(() -> Toast.makeText(MainActivity.this, "Error de conexión: " + e.getMessage(), Toast.LENGTH_SHORT).show());
            e.printStackTrace();
        }
    }
}
