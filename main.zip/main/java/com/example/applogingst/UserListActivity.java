package com.example.applogingst;

import android.database.Cursor;  // Importación de Cursor
import android.os.Bundle;
import android.os.StrictMode;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class UserListActivity extends AppCompatActivity {

    private ListView listView;
    private ArrayList<String> userList;
    private DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_list);

        listView = findViewById(R.id.listView);
        userList = new ArrayList<>();
        dbHelper = new DBHelper(this);

        // Configurar StrictMode para permitir operaciones de red en el hilo principal (mejor usar AsyncTask o similares en producción)
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        // Cargar usuarios desde el servidor o la base de datos local
        loadUsers();
    }

    private void loadUsers() {
        String urlString = "http://10.0.2.2/applogingst/get_users.php"; // Cambia según tu servidor
        try {
            // Primero intentamos cargar usuarios desde el servidor
            URL url = new URL(urlString);
            HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.setRequestMethod("GET");

            BufferedReader in = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
            String responseLine;
            StringBuilder response = new StringBuilder();
            while ((responseLine = in.readLine()) != null) {
                response.append(responseLine);
            }
            in.close();

            // Parsear la respuesta JSON
            JSONObject jsonResponse = new JSONObject(response.toString());
            if (jsonResponse.getString("status").equals("success")) {
                // Borrar los usuarios antiguos de la base de datos SQLite
                dbHelper.deleteAllUsers();

                JSONArray data = jsonResponse.getJSONArray("data");
                for (int i = 0; i < data.length(); i++) {
                    JSONObject user = data.getJSONObject(i);
                    String userName = user.getString("user");
                    String userPass = user.getString("pass");

                    // Insertamos el usuario en la base de datos SQLite
                    dbHelper.addUser(userName, userPass);
                }

                // Mostrar los datos en el ListView
                loadUsersFromDatabase();
            } else {
                Toast.makeText(this, "No se pudieron cargar los usuarios del servidor", Toast.LENGTH_SHORT).show();
                loadUsersFromDatabase(); // Cargar usuarios desde la base de datos local si no se pudo acceder al servidor
            }

        } catch (Exception e) {
            Toast.makeText(this, "Error al conectar: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            e.printStackTrace();
            loadUsersFromDatabase(); // Cargar usuarios desde la base de datos local si hay un error de conexión
        }
    }

    // Cargar los usuarios desde la base de datos SQLite
    private void loadUsersFromDatabase() {
        Cursor cursor = dbHelper.getAllUsers();
        if (cursor != null && cursor.moveToFirst()) {
            userList.clear();

            // Obtener índices de las columnas
            int userColumnIndex = cursor.getColumnIndex(DBHelper.COLUMN_USER);
            int passColumnIndex = cursor.getColumnIndex(DBHelper.COLUMN_PASS);

            // Verificar que las columnas existan (índice >= 0)
            if (userColumnIndex >= 0 && passColumnIndex >= 0) {
                do {
                    String user = cursor.getString(userColumnIndex);
                    String pass = cursor.getString(passColumnIndex);
                    userList.add("Usuario: " + user + ", Pass: " + pass);
                } while (cursor.moveToNext());

                // Mostrar los datos en el ListView
                ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, userList);
                listView.setAdapter(adapter);
            } else {
                Toast.makeText(this, "Las columnas no existen en la base de datos", Toast.LENGTH_SHORT).show();
            }

            cursor.close();
        } else {
            Toast.makeText(this, "No hay datos disponibles", Toast.LENGTH_SHORT).show();
        }
    }
}
